from .hypo import HYPO
from .tppo import TPPO, TPPOExpert


ALGOS = {
    'hypo': HYPO,
    'tppo': TPPO,
}

EXP = {
    'tppo': TPPOExpert
}
